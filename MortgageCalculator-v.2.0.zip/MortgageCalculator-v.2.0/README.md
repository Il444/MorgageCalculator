# Мобильное приложение КАЛЬКУЛЯТОР ИПОТЕКИ на Python + Kivy
Привет друзья! Здесь постепенно будет выкладываться код к урокам по созданию мобильного приложения КАЛЬКУЛЯТОР ИПОТЕКИ.
### Мобильное приложение будет опубликовано на Apple Store и Google Play.

##### <a href="README-ru.md">посмотреть на Русском</a>

# Mobile application MORTGAGE CALCULATOR (Python + Kivy)
Hello friends! Here, the code for the lessons on creating a mobile MORTGAGE CALCULATOR application will gradually be laid out.
### The mobile app will be published on the Apple Store and Google Play.

##### <a href="README-en.md">read on English</a> 

## 🌟 Если вам нравится такой контент, и вы хотите больше такого контента,
## 🌟 то поддержи этот проект: https://yoomoney.ru/to/4100115287401838 
## 🌟 по номеру карты: 5599005072205482 
