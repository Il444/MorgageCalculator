# Mobile application MORTGAGE CALCULATOR (Python + Kivy)
Hello friends! Here, the code for the lessons on creating a mobile MORTGAGE CALCULATOR application will gradually be laid out.
##### 🌟 What will be in this mobile app:
1) mortgage settlement with annuity and differentiated payments
2) multiple menu views
3) tabs
4) charts
5) support multiple languages: English, Russian
6) ad display

### The mobile app will be published on the Apple Store and Google Play.

## 🌟 If you like this kind of content and you want more of this kind of content,
## 🌟 then support this project: https://yoomoney.ru/to/4100115287401838
## 🌟 by card number: 5599005072205482
